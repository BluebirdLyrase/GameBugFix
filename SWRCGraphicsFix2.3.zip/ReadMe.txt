This is a mod for Star Wars Republic Commando that fixes the infamous bumpmapping crash when loading a map or when looking at textures in the Unreal Editor.
It does not only fix the crash but also removes the visual artifacts on characters and other meshes that use bumpmaps.
Since no original game packages were modified multiplayer will still work just fine.
Additionally, the mod adds more widescreen resolution options up to 4k and a FOV slider.
The FOV slider allows setting the field of view in steps of 5 degrees. If you want finer control, you can use the 'SETFOV' console command.
There also is another menu option called 'Weapon FOV Factor' which controls how much the FOV will affect the weapons since it can look rather strange if the FOV is very high.
The mod also restores the multiplayer server browser.

Version 2.3
 - Fixed slow performance when selecting stuff in the Editor (can be disabled using the "FIXSELECT" console command)

Version 2.2
 - Disabled FpsLimit option in Multiplayer as it has no effect there because the engine sets its own limit
 - Fixed Battle Droids using clone weapons in first mission
 - Fixed crash that could happen when leaving MP and starting a campaign map or vice versa
 - Fixed UnrealEd crash when placing a FluidSurfaceInfo
 - Fixed UnrealEd crash when editing object properties (mostly happened with menu classes)

Version 2.1
 - Fixed crash in UnrealEd when opening the StaticMesh browser
 - Added fps limit menu option. Limiting the fps can help with the menu mouse sensitivity and other fps bound problems like the extreme Helmet shaking. The limit can also be set using the `SetFpsLimit <number>` console command

Installation:
Copy all files to the Game's 'GameData\System' directory.

made by Leon0628

swrc-modding.net
https://www.youtube.com/channel/UCD7BHhdtWyBQ8HNr6xg4OxQ